import React, {Component} from 'react';
import CarouselAbout from "../CarouselComponents/CarouselAbout";

class About extends Component {
    render() {
        return (
            <CarouselAbout/>
        );
    }
}

export default About;