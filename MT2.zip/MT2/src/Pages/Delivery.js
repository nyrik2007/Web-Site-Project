import React, {Component} from 'react';
import CarouselDelivery from "../CarouselComponents/CarouselDelivery";

class Delivery extends Component {
    render() {
        return (
            <CarouselDelivery/>
        );
    }
}

export default Delivery;