import React, {Component} from 'react';
import Carousel from "react-bootstrap/Carousel";
import topor from "../photos/topor.jpg";
import cement from "../photos/cement.jpg";
import laminat from "../photos/laminat.jpg";
import molotki from "../photos/molotki.jpg";
import kafel from "../photos/kafel.jpg";

class CarouselStore extends Component {
    render() {
        return (
            <Carousel>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src={topor}
                        alt='tovary'
                    />

                    <Carousel.Caption>
                        <h2>Топор-Fiskars x27</h2>
                        <p>Цена:5000тнг | Артикул: #0001 </p>
                    </Carousel.Caption>
                </Carousel.Item>



                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src={kafel}
                        alt='tovary'
                    />

                    <Carousel.Caption>
                        <h2>Кафель цвет:Мрамор</h2>
                        <p>Цена:8000тнг/1 | Артикул: #0592 </p>
                    </Carousel.Caption>
                </Carousel.Item>



                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src={laminat}
                        alt='tovary'
                    />

                    <Carousel.Caption>
                        <h2>Ламинат:Classen</h2>
                        <p>Цена:12000тнг/1 | Артикул: #1236 </p>
                    </Carousel.Caption>
                </Carousel.Item>



                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src={molotki}
                        alt='tovary'
                    />

                    <Carousel.Caption>
                        <h2>Молотки:Epicastar</h2>
                        <p>Цена:4000тнг/1 | Артикул: #1992 </p>
                    </Carousel.Caption>
                </Carousel.Item>



                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src={cement}
                        alt='tovary'
                    />

                    <Carousel.Caption>
                        <h2>Портландцемент с минеральными добавками</h2>
                        <p>Цена:3000тнг/1 | Артикул: #9999 </p>
                    </Carousel.Caption>
                </Carousel.Item>
            </Carousel>

        );
    }
}

export default CarouselStore;