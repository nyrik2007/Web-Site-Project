import firebase from "firebase/app";
import "firebase/auth";

const app = firebase.initializeApp({
    apiKey: "AIzaSyC7ZAz8qtxaaZ9kuVhKVEIhC6snF26xJWQ",
    authDomain: "web-site-project-d4cef.firebaseapp.com",
    projectId: "web-site-project-d4cef",
    storageBucket: "web-site-project-d4cef.appspot.com",
    messagingSenderId: "561414512347",
    appId: "1:561414512347:web:f40ddb0c69ba95241bf6fe"
});

export default app;
