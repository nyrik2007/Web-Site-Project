import React, {Component} from "react";
import app from "./base";
import {Navbar, Nav, Container, Form, FormControl} from 'react-bootstrap';
import NavbarToggle from "react-bootstrap/NavbarToggle";
import Button from "react-bootstrap/Button";
import 'bootstrap/dist/css/bootstrap.min.css';  //импортим стили для бутстрапа
import logo from "./photos/logo.jpeg"; //импортируем лого из папки с фотками
import {BrowserRouter as Router, Route, Switch, Link} from "react-router-dom"; //importing react router dom

import About from "./Pages/About";
import Store from "./Pages/Store";
import Contact from "./Pages/Contact";
import Delivery from "./Pages/Delivery";


export default class Home extends Component {
    render() {
        return (
            <>
            <Router>
                <Navbar collapseOnSelect expand='md' bg='dark' variant='dark'>
                    <Container>
                        <Navbar.Brand>
                            <img
                                src={logo} //ссылка на лого
                                height='50' //высота
                                width='50' //ширина
                                className='d-inline-block align-top'
                                alt='Logo' //альтернативный текст
                            />
                        </Navbar.Brand>
                        <Navbar.Toggle aria-controls='responsive-navbar-nav'/>
                        <Navbar.Collapse id="responsive-navbar-nav">
                            <Nav className='mr-auto'>
                                <Link to="/">О нас</Link>
                                <Link to='/store'>Магазин</Link>
                                <Link to='/contact'>Контактная информация</Link>
                                <Link to='/delivery'>Доставка</Link>
                            </Nav>
                            <Form inline>
                                <FormControl
                                    type='text'
                                    placeholder='Search'
                                    className='mr-sm-2' //margin-tight small-2
                                />
                                <Button variant='outline-info'>Search</Button>
                            </Form>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>



                    <Switch>
                        <Route exact path='/' component={About}/>
                        <Route exact path='/store' component={Store}/>
                        <Route exact path='/contact' component={Contact}/>
                        <Route exact path='/delivery' component={Delivery}/>
                    </Switch>
                </Router>
            </>
        )
    };
};

