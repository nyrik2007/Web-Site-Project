import React, {Component} from 'react';
import Carousel from "react-bootstrap/Carousel";
import contact from "../photos/contact.jpeg";

class CarouselContact extends Component {
    render() {
        return (
            <Carousel>
                <Carousel.Item>
                    <img
                        className='d-block w-100'
                        src={contact}
                        alt='contactus'
                    />
                    <Carousel.Caption>
                        <h2>Свяжитесь с нами!</h2>
                    </Carousel.Caption>
                </Carousel.Item>
            </Carousel>
        );
    }
}

export default CarouselContact;