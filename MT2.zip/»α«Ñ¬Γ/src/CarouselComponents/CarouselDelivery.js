import React, {Component} from 'react';
import Carousel from "react-bootstrap/Carousel";
import delivery from "../photos/delivery.jpeg";


class CarouselDelivery extends Component {
    render() {
        return (
            <Carousel>
                <Carousel.Item>
                    <img
                        className='d-block w-100'
                        src={delivery}
                        alt='delivery'
                    />
                </Carousel.Item>
                <Carousel.Caption>
                    <h2>Закажите у нас!</h2>
                </Carousel.Caption>
            </Carousel>
        );
    }
}

export default CarouselDelivery;