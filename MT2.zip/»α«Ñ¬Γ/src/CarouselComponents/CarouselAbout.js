import React, {Component} from 'react';
import Carousel from "react-bootstrap/Carousel";
import about1 from "../photos/about1.jpg";
import about2 from "../photos/about2.jpg";
import about from "../photos/about.jpeg";



class CarouselAbout extends Component {
    render() {
        return (
            <Carousel>
                <Carousel.Item>
                    <img
                        className='d-block w-100'//обычный бутстраповский класс
                        src={about}
                        alt='aboutus'
                    />
                    <Carousel.Caption>
                        <h2>О нас</h2>
                    </Carousel.Caption>
                </Carousel.Item>


                <Carousel.Item>
                    <img
                        className='d-block w-100'//обычный бутстраповский класс
                        src={about1}
                        alt='aboutus'
                    />
                    <Carousel.Caption>
                        <h2>О нас</h2>
                    </Carousel.Caption>
                </Carousel.Item>


                <Carousel.Item>
                    <img
                        className='d-block w-100'//обычный бутстраповский класс
                        src={about2}
                        alt='aboutus'
                    />
                    <Carousel.Caption>
                        <h2>О нас</h2>
                    </Carousel.Caption>
                </Carousel.Item>
            </Carousel>
        );
    }
}

export default CarouselAbout;