import React, {Component} from 'react';
import CarouselStore from "../CarouselComponents/CarouselStore";

class Store extends Component {
    render() {
        return (
            <CarouselStore/>
        );
    }
}

export default Store;