import React, {Component} from 'react';
import CarouselContact from "../CarouselComponents/CarouselContact";

class Contact extends Component {
    render() {
        return (
            <CarouselContact/>
        );
    }
}

export default Contact;